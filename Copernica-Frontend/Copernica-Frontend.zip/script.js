//****DONE*** */

// loading animation
// style border seprately
// loading animation + wait timer(http request, blue 3 px, 1 second or random
// switch image
// loopable
//highlight selected avatar

//**** TO DO */


//insert Jquery and ajust code

// proper html semantics <ul> <li>

// mouse cursor

// click outside element

// delete obsolete code





appController = (function(){
    
    var newAvatar = 1;    
    var elements = {
        avatar: '.current_avatar',
        popover: '.popover',
        selectBorder: '.border',
        shown: false,    
    };
    var allSelectedBorders = document.querySelectorAll(elements.selectBorder);
    

    setupEventListeners = function()
    {    
        
        document.querySelector(elements.avatar).addEventListener('click', function() 
        {
            if(!elements.shown){
                expandMenu(); 
            } else{
                
            hideMenu(); 
            }
        });       
        
        document.querySelector(elements.selectBorder).addEventListener('click', loadAnimation);
        
        var whichAvatar = document.querySelectorAll(elements.selectBorder);
            for(var i = 0; i< whichAvatar.length; i++){
                whichAvatar[i].addEventListener('webkitAnimationEnd', hideMenu);
            };  
            
        document.addEventListener('click', function(event){
            if ((elements.shown && !event.target.closest('.avatar_elements')) && 
            (elements.shown && !event.target.closest('.your_avatar'))){
                
                hideMenu();
            }
        });  
    };


    expandMenu = function()
    { 
        
        if(elements.shown === false){
            document.querySelector(elements.popover).classList.add("animate");
            document.querySelector(elements.popover).classList.remove("closed");
            document.querySelector(elements.avatar).classList.add('selected');
            
            elements.shown = true;
        }else{
                hideMenu();
                elements.shown = false;
            };
    };

    hideMenu = function() {
        document.querySelector(elements.popover).classList.remove('animate');
        document.querySelector(elements.popover).classList.add("closed");
        document.querySelector(elements.avatar).classList.remove('selected');        
        
        for(var i = 0; i< allSelectedBorders.length; i++){
            allSelectedBorders[i].classList.remove('animateBorder');
        }; 
        elements.shown = false;
        changeAvatar();        
    };

    deleteSelection = function(){
        document.querySelector(elements.avatar).classList.remove('selected');
    }

    // el get passed from CSS div
    loadAnimation = function(el){
        switch(el){
            case '1':
            document.getElementById('border_1').classList.add("animateBorder");
            newAvatar = '1';
            deleteSelection();
            break;
            case '2':
            document.getElementById('border_2').classList.add("animateBorder");
            newAvatar = '2';
            deleteSelection();
            break;
            case '3':
            document.getElementById('border_3').classList.add("animateBorder");
            newAvatar = '3';
            deleteSelection();
            break;
            case '4':
            document.getElementById('border_4').classList.add("animateBorder");
            newAvatar = '4';
            deleteSelection();
            break;
            case '5':
            document.getElementById('border_5').classList.add("animateBorder");
            newAvatar = '5';
            deleteSelection();
            break;
            case '6':
            document.getElementById('border_6').classList.add("animateBorder");
            newAvatar = '6';
            deleteSelection();
            break;
        };
    };

    changeAvatar = function()
    {
        document.querySelector(elements.avatar).src='images/img' + newAvatar + '.png';

        
        for(var i = 0; i< allSelectedBorders.length; i++){
            allSelectedBorders[i].classList.remove('selected');
        };
        document.getElementById('border_' + newAvatar).classList.add("selected");
    };

return {
    init: function()
    {
        console.log('Application has started');
        setupEventListeners();
        changeAvatar();
    }
}

})();
appController.init();